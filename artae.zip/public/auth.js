(()=>{'use strict';
const gate=document.getElementById('authGate'),app=document.getElementById('app'),toolbar=document.getElementById('authToolbar');
let currentUser=null,loaded=false,initialized=false;
const api=async(action,data=null)=>{
 const url='/.netlify/functions/auth'+(data===null?'?action='+encodeURIComponent(action):'');
 const opts={credentials:'same-origin',cache:'no-store'};
 if(data!==null){opts.method='POST';opts.headers={'Content-Type':'application/json'};opts.body=JSON.stringify({action,...data})}
 const res=await fetch(url,opts);let body={};try{body=await res.json()}catch{}
 if(!res.ok)throw new Error(body.error||'Сервер временно недоступен');
 return body;
};
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function renderGate(mode='login',message=''){
 app.hidden=true;toolbar.hidden=true;gate.hidden=false;
 gate.innerHTML=`<div class="authBox"><h1>АРТ-АЕ</h1><p>Закрытое пространство проектов</p>${message?`<div class="authNotice" role="status">${escape(message)}</div>`:''}
 <form id="authForm">
 ${mode==='bootstrap'?`<label for="authName">Имя администратора</label><input id="authName" autocomplete="name" maxlength="80" value="Администратор" required><label for="setupKey">Установочный ключ Netlify</label><input id="setupKey" type="password" autocomplete="off" required>`:`<label for="accessKey">Ваш секретный ключ доступа</label><input id="accessKey" type="password" autocomplete="off" required>`}
 <button type="submit">${mode==='bootstrap'?'Создать администратора':'Войти'}</button></form>
 ${mode==='bootstrap'?'<p class="authHint">Только при первоначальной настройке. Используйте ARTAE_SETUP_KEY из Netlify.</p>':'<p class="authHint">Ключ выдаёт администратор. На этом устройстве вход сохраняется.</p>'}</div>`;
 document.getElementById('authForm').addEventListener('submit',async e=>{
  e.preventDefault();const b=e.target.querySelector('button');b.disabled=true;b.textContent='Проверяем…';
  try{if(mode==='bootstrap'){
    const result=await api('bootstrap',{setupKey:document.getElementById('setupKey').value,name:document.getElementById('authName').value});
    showKey(result.accessKey,'Ключ администратора. Сохраните его сейчас: повторно он не показывается.',()=>renderGate('login'));
  }else{const result=await api('login',{accessKey:document.getElementById('accessKey').value});enter(result.user)}
  }catch(err){renderGate(mode,err.message)}
 });
}
function showKey(key,title,next){
 app.hidden=true;toolbar.hidden=true;gate.hidden=false;
 gate.innerHTML=`<div class="authBox"><h1>Сохраните ключ</h1><p>${escape(title)}</p><textarea id="generatedKey" readonly rows="3"></textarea><button id="copyKey" type="button">Скопировать ключ</button><button id="doneKey" type="button">Ключ сохранён, продолжить</button><p class="authHint">Ключ нельзя восстановить из системы. При утере ключа пользователя администратор выдаёт новый.</p></div>`;
 document.getElementById('generatedKey').value=key;
 document.getElementById('copyKey').onclick=async()=>{try{await navigator.clipboard.writeText(key);document.getElementById('copyKey').textContent='Скопировано'}catch{document.getElementById('generatedKey').select()}};
 document.getElementById('doneKey').onclick=()=>{document.getElementById('generatedKey').value='';next()};
}
async function logout(){
 try{await api('logout',{});currentUser=null;renderGate('login')}catch(e){alert(e.message)}
}
window.ARTAE_AUTH={
 getUser:()=>currentUser,
 showAdmin:()=>{if(currentUser?.role==='admin')return showAdmin()},
 logout
};
function enter(user){currentUser=user;gate.hidden=true;app.hidden=false;toolbar.hidden=true;toolbar.innerHTML='';
 if(!loaded){loaded=true;const s=document.createElement('script');s.src='app.js';document.body.append(s)}
}
async function showAdmin(){
 try{const response=await api('users');
  gate.hidden=false;app.hidden=true;toolbar.hidden=true;
  gate.innerHTML=`<div class="authBox"><h1>Пользователи</h1><p>Управление доступом · максимум 5 аккаунтов</p><div id="userRows"></div><form id="createUser"><label for="newUserName">Новый пользователь</label><input id="newUserName" maxlength="80" placeholder="Имя" required><button>Создать и выдать ключ</button></form><button id="adminBack" class="authSecondary">Назад в АРТ-АЕ</button><div class="authHint" id="adminMsg"></div></div>`;
  const rows=document.getElementById('userRows');
  response.users.forEach(u=>{
   const div=document.createElement('div');div.className='authUserRow';
   const title=document.createElement('span');title.textContent=u.name+(u.role==='admin'?' · администратор':u.disabled?' · отключён':'');div.append(title);
   if(u.role!=='admin'&&!u.disabled){
    const reset=document.createElement('button');reset.textContent='Новый ключ';reset.onclick=async()=>{if(!confirm('Старый ключ и все текущие сессии этого пользователя перестанут работать. Продолжить?'))return;try{const r=await api('reissueKey',{userId:u.id});showKey(r.accessKey,'Новый ключ пользователя '+u.name+'. Старый ключ отозван.',showAdmin)}catch(e){alert(e.message)}};div.append(reset);
    const disable=document.createElement('button');disable.textContent='Отключить';disable.onclick=async()=>{if(!confirm('Отключить '+u.name+'?'))return;try{await api('disableUser',{userId:u.id});showAdmin()}catch(e){alert(e.message)}};div.append(disable);
   }rows.append(div)
  });
  document.getElementById('adminBack').onclick=()=>enter(currentUser);
  document.getElementById('createUser').onsubmit=async e=>{e.preventDefault();try{const name=document.getElementById('newUserName').value;const r=await api('createUser',{name});showKey(r.accessKey,'Передайте этот ключ пользователю '+r.user.name+'. Он показывается только сейчас.',showAdmin)}catch(e){document.getElementById('adminMsg').textContent=e.message}};
 }catch(e){alert(e.message);enter(currentUser)}
}
async function startup(){renderGate('login','Проверяем доступ…');try{const me=await api('me');enter(me.user)}catch{
 try{const status=await api('status');initialized=status.initialized;renderGate(initialized?'login':'bootstrap')}catch{renderGate('login','Не удалось связаться с сервером. Проверьте подключение и повторите загрузку страницы.')}
}}
startup();
})();
