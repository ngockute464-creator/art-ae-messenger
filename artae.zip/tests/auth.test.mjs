import assert from 'node:assert/strict';
import handler from '../netlify/functions/auth.mjs';
process.env.YANDEX_DISK_TOKEN='MOCK_TOKEN';process.env.ARTAE_SETUP_KEY='test_secret_setup_key_1234567890';
const files=new Map();const dirs=new Set();
const originalFetch=global.fetch;
global.fetch=async(input,options={})=>{
 const u=new URL(input), method=options.method||'GET';
 if(u.hostname==='mock.yandex.net'){
  const path=decodeURIComponent(u.pathname.slice(1));
  if(method==='PUT'){if(u.searchParams.get('overwrite')==='false'&&files.has(path))return new Response('',{status:409});files.set(path,String(options.body));return new Response('',{status:201})}
  if(method==='GET')return files.has(path)?new Response(files.get(path),{status:200}):new Response('',{status:404});
 }
 if(u.hostname!=='cloud-api.yandex.net')throw new Error('Wrong URL '+u);
 const path=u.searchParams.get('path');
 if(u.pathname.endsWith('/resources/upload'))return Response.json({href:'https://mock.yandex.net/'+encodeURIComponent(path)+'?overwrite='+u.searchParams.get('overwrite'),method:'PUT'});
 if(u.pathname.endsWith('/resources/download'))return files.has(path)?Response.json({href:'https://mock.yandex.net/'+encodeURIComponent(path)}):Response.json({error:'not found'},{status:404});
 if(u.pathname.endsWith('/resources')){
  if(method==='PUT'){if(dirs.has(path))return Response.json({error:'exists'},{status:409});dirs.add(path);return Response.json({ok:true},{status:201})}
  if(method==='DELETE'){if(!files.has(path))return Response.json({error:'not found'},{status:404});files.delete(path);return new Response(null,{status:204})}
 }
 throw new Error('unhandled '+u+' '+method);
};
const base='https://art-ae-messenger.netlify.app/.netlify/functions/auth';
let adminCookie='',memberCookie='';
async function call(action,params=null,cookie=''){
 const isGet=params===null;
 const response=await handler(new Request(base+(isGet?'?action='+action:''),{method:isGet?'GET':'POST',headers:{...(isGet?{}:{'Content-Type':'application/json',Origin:'https://art-ae-messenger.netlify.app'}),...(cookie?{Cookie:cookie}:{})},...(isGet?{}:{body:JSON.stringify({action,...params})})}));
 return {status:response.status,body:await response.json(),cookie:response.headers.get('set-cookie')};
}
try{
 let r=await call('status');assert.equal(r.body.initialized,false);
 r=await call('bootstrap',{setupKey:'bad setup',name:'Admin'});assert.equal(r.status,403);
 r=await call('bootstrap',{setupKey:process.env.ARTAE_SETUP_KEY,name:'Admin'});assert.equal(r.status,200);const adminKey=r.body.accessKey;assert.equal(adminKey.length,43);
 r=await call('bootstrap',{setupKey:process.env.ARTAE_SETUP_KEY,name:'Admin'});assert.equal(r.status,409);
 r=await call('login',{accessKey:'invalid'});assert.equal(r.status,401);
 r=await call('login',{accessKey:adminKey});assert.equal(r.status,200);adminCookie=r.cookie.split(';')[0];assert.match(r.cookie,/HttpOnly/);assert.match(r.cookie,/SameSite=Strict/);
 r=await call('me',null,adminCookie);assert.equal(r.body.user.role,'admin');
 r=await call('createUser',{name:'Second'},adminCookie);assert.equal(r.status,200);const memberKey=r.body.accessKey,memberId=r.body.user.id;
 r=await call('login',{accessKey:memberKey});memberCookie=r.cookie.split(';')[0];assert.equal(r.status,200);
 r=await call('users',null,memberCookie);assert.equal(r.status,403);
 r=await call('reissueKey',{userId:memberId},adminCookie);assert.equal(r.status,200);const newKey=r.body.accessKey;
 r=await call('me',null,memberCookie);assert.equal(r.status,401);
 r=await call('login',{accessKey:memberKey});assert.equal(r.status,401);
 r=await call('login',{accessKey:newKey});assert.equal(r.status,200);memberCookie=r.cookie.split(';')[0];
 r=await call('disableUser',{userId:memberId},adminCookie);assert.equal(r.status,200);
 r=await call('me',null,memberCookie);assert.equal(r.status,401);
 r=await call('logout',{},adminCookie);assert.equal(r.status,200);
 r=await call('me',null,adminCookie);assert.equal(r.status,401);
 console.log('PASS: admin bootstrap, login, persistent session, user creation, reissue, disable, logout, role checks');
} finally{global.fetch=originalFetch}
