import assert from 'node:assert/strict';
import auth from '../netlify/functions/auth.mjs';
import sync from '../netlify/functions/sync.mjs';
process.env.YANDEX_DISK_TOKEN='MOCK_TOKEN';process.env.ARTAE_SETUP_KEY='super_secure_setup_key_for_tests_999';
const files=new Map(),dirs=new Set();const originalFetch=global.fetch;
global.fetch=async(input,opts={})=>{
 const u=new URL(input),method=opts.method||'GET';
 if(u.hostname==='mock.yandex.net'){
  const path=decodeURIComponent(u.pathname.slice(1));
  if(method==='PUT'){
   if(u.searchParams.get('overwrite')==='false'&&files.has(path))return new Response('',{status:409});
   files.set(path,{body:String(opts.body),modified:new Date().toISOString()});return new Response('',{status:201});
  }
  const f=files.get(path);return f?new Response(f.body,{status:200}):new Response('',{status:404});
 }
 if(u.hostname!=='cloud-api.yandex.net')throw Error('Unexpected '+u);
 const path=u.searchParams.get('path');
 if(u.pathname.endsWith('/resources/download'))return files.has(path)?Response.json({href:'https://mock.yandex.net/'+encodeURIComponent(path)}):Response.json({error:'missing'},{status:404});
 if(u.pathname.endsWith('/resources/upload'))return Response.json({href:'https://mock.yandex.net/'+encodeURIComponent(path)+'?overwrite='+u.searchParams.get('overwrite'),method:'PUT'});
 if(u.pathname.endsWith('/resources')){
  if(method==='PUT'){if(dirs.has(path))return Response.json({error:'exists'},{status:409});dirs.add(path);return Response.json({}, {status:201})}
  if(method==='DELETE'){files.delete(path);return new Response(null,{status:204})}
  if(!dirs.has(path))return Response.json({error:'missing'},{status:404});
  const entries=[...dirs].filter(x=>x.startsWith(path+'/')&&!x.slice(path.length+1).includes('/')).map(x=>({name:x.split('/').at(-1),type:'dir',modified:new Date().toISOString()}));
  for(const [name,item] of files)if(name.startsWith(path+'/')&&!name.slice(path.length+1).includes('/'))entries.push({name:name.slice(path.length+1),type:'file',modified:item.modified});
  const off=Number(u.searchParams.get('offset')||0),lim=Number(u.searchParams.get('limit')||100);return Response.json({_embedded:{items:entries.slice(off,off+lim),total:entries.length}});
 }
 throw Error('unhandled '+u);
};
const origin='https://art-ae-messenger.netlify.app',base=origin+'/.netlify/functions/';
async function call(fn,action,body=null,cookie=''){
 const get=body===null;const req=new Request(base+fn+(get?'?'+new URLSearchParams({action}):''),{method:get?'GET':'POST',headers:{...(get?{}:{Origin:origin,'Content-Type':'application/json'}),...(cookie?{Cookie:cookie}:{})},...(get?{}:{body:JSON.stringify({action,...body})})});
 const res=await(fn==='auth'?auth:sync)(req);return {status:res.status,data:await res.json(),cookie:res.headers.get('set-cookie')};
}
try{
 let r=await call('auth','bootstrap',{setupKey:process.env.ARTAE_SETUP_KEY,name:'Admin'});assert.equal(r.status,200);
 const adminKey=r.data.accessKey;
 r=await call('auth','login',{accessKey:adminKey});const admin=r.cookie.split(';')[0];
 r=await call('auth','createUser',{name:'Member'},admin);const memberKey=r.data.accessKey;
 r=await call('auth','login',{accessKey:memberKey});const member=r.cookie.split(';')[0];
 assert.equal((await call('sync','overview')).status,401);
 assert.equal((await call('sync','overview',null,admin)).data.projects.length,0);
 r=await call('sync','createProject',{name:'Атлас исчезнувших историй'},admin);assert.equal(r.status,200);const p=r.data.project;
 assert.equal(p.folderPath,'app:/Атлас исчезнувших историй');assert(dirs.has(p.folderPath));
 r=await call('sync','createConvo',{project:p.id,name:'Разработка'},member);assert.equal(r.status,200);const c=r.data.convo;
 const send1=()=>call('sync','send',{convo:c.id,text:'Сообщение от администратора'},admin);
 const send2=()=>call('sync','send',{convo:c.id,text:'Сообщение от участника'},member);
 const [a,b]=await Promise.all([send1(),send2()]);assert.equal(a.status,200);assert.equal(b.status,200);assert.notEqual(a.data.message.id,b.data.message.id);
 r=await call('sync','messages',null,member);assert.equal(r.status,400);
 const u=base+'sync?'+new URLSearchParams({action:'messages',convo:c.id});
 let read=await sync(new Request(u,{headers:{Cookie:member}}));let result=await read.json();assert.equal(result.messages.length,2);
 r=await call('sync','edit',{id:a.data.message.id,convo:c.id,text:'Чужая правка'},member);assert.equal(r.status,403);
 r=await call('sync','edit',{id:a.data.message.id,convo:c.id,text:'Исправлено'},admin);assert.equal(r.status,200);
 r=await call('sync','delete',{id:b.data.message.id,convo:c.id},admin);assert.equal(r.status,403);
 r=await call('sync','delete',{id:b.data.message.id,convo:c.id},member);assert.equal(r.status,200);
 read=await sync(new Request(u,{headers:{Cookie:member}}));result=await read.json();assert.equal(result.messages.filter(x=>!x.deletedAt).length,1);
 assert.equal(result.messages.find(x=>x.id===a.data.message.id).text,'Исправлено');
 r=await call('sync','updateProject',{id:p.id,name:'Атлас v2'},member);assert.equal(r.status,200);
 assert.equal((await call('sync','overview',null,admin)).data.projects[0].name,'Атлас v2');
 assert.equal((await call('sync','createConvo',{project:'bad',name:'No'},member)).status,404);
 console.log('PASS: shared projects, folder, conversations, concurrent sends, reload, ownership, edits, tombstones');
}finally{global.fetch=originalFetch}
