// Test-only probe. Never expose a Yandex OAuth token in client code.
// No chat data is created or modified. A unique temporary JSON is written, read and deleted.
import { randomUUID, timingSafeEqual } from 'node:crypto';

const api = 'https://cloud-api.yandex.net/v1/disk';
const json = (obj, status=200) => Response.json(obj, {status, headers:{'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff'}});
const cmp = (a,b) => { const x=Buffer.from(String(a||'')), y=Buffer.from(String(b||'')); return x.length>0 && x.length===y.length && timingSafeEqual(x,y); };

async function yandex(path,method='GET') {
  const u=new URL(api+path);
  const r=await fetch(u,{method,headers:{Authorization:`OAuth ${process.env.YANDEX_DISK_TOKEN}`},signal:AbortSignal.timeout(12000)});
  let body={}; const raw=await r.text();try{body=JSON.parse(raw)}catch{}
  if(!r.ok) throw new Error(`Yandex API ${r.status}: ${String(body.error||body.message||'request failed').slice(0,150)}`);
  return body;
}
function trustedTransfer(href){
  const u=new URL(href); const host=u.hostname.toLowerCase();
  if(u.protocol!=='https:' || !(host==='yandex.ru'||host.endsWith('.yandex.ru')||host.endsWith('.yandex.net')||host.endsWith('.yandex.com')))throw new Error('Unexpected transfer host');
  return u.toString();
}
export default async function handler(request) {
  if(request.method!=='POST')return json({error:'POST only'},405);
  const key=process.env.ARTAE_SETUP_KEY;
  if(!key || key.length<20 || !cmp(request.headers.get('x-setup-key'),key))return json({error:'Доступ запрещён: проверь ARTAE_SETUP_KEY'},403);
  if(!process.env.YANDEX_DISK_TOKEN)return json({error:'Не задан YANDEX_DISK_TOKEN'},503);
  const id=randomUUID(), path=`app:/art-ae-test-${id}.json`;
  const contents=JSON.stringify({type:'art-ae-storage-test',id,createdAt:new Date().toISOString()});
  let uploaded=false;
  try {
    const upload=await yandex(`/resources/upload?${new URLSearchParams({path,overwrite:'false'})}`);
    const put=await fetch(trustedTransfer(upload.href),{method:upload.method||'PUT',body:contents,headers:{'Content-Type':'application/json'},signal:AbortSignal.timeout(12000)});
    if(!put.ok)throw new Error(`Upload HTTP ${put.status}`);
    uploaded=true;
    const download=await yandex(`/resources/download?${new URLSearchParams({path})}`);
    const get=await fetch(trustedTransfer(download.href),{signal:AbortSignal.timeout(12000)});
    if(!get.ok)throw new Error(`Download HTTP ${get.status}`);
    const actual=await get.text();
    if(actual!==contents)throw new Error('Файл прочитан, но данные отличаются');
    await yandex(`/resources?${new URLSearchParams({path,permanently:'true'})}`,'DELETE');
    return json({ok:true,checks:{upload:true,read:true,contentsMatch:true,remove:true},message:'Проверка завершена. Временный JSON удалён.'});
  } catch(e) {
    // On a failed read, attempt to clean up only our unique test object.
    let cleaned=false;
    if(uploaded){try{await yandex(`/resources?${new URLSearchParams({path,permanently:'true'})}`,'DELETE');cleaned=true}catch{}}
    return json({ok:false,error:String(e.message||e).slice(0,220),cleanup:uploaded?(cleaned?'Временный файл удалён':'Удаление временного файла не подтверждено'):'Загрузка не завершена',testFile:id},502);
  }
}
