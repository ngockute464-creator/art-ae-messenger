// ART-AE stage 2: conservative shared projects and text messages over Yandex app folder.
// One file per record: concurrent SENDs cannot overwrite each other.
import {randomUUID} from 'node:crypto';
import {getSession} from './auth.mjs';
const API='https://cloud-api.yandex.net/v1/disk';
const ROOT='app:/_system';
const PROJECTS=ROOT+'/shared-projects',CONVOS=ROOT+'/shared-conversations',MESSAGES=ROOT+'/shared-messages';
const jsonHeaders={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const reply=(v,status=200)=>Response.json(v,{status,headers:jsonHeaders});
const qs=o=>new URLSearchParams(o).toString();
const uuid=s=>typeof s==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
const trimmed=(v,max)=>typeof v==='string'?v.trim().slice(0,max):'';
const safeFolderName=name=>name.replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').replace(/\.+$/,'').trim().slice(0,90)||'Проект';
const validAvatar=x=>x===null||typeof x==='string'&&x.length<=80000&&/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(x);
const now=()=>Date.now();
async function api(path,method='GET'){
 const r=await fetch(API+path,{method,headers:{Authorization:`OAuth ${process.env.YANDEX_DISK_TOKEN}`},signal:AbortSignal.timeout(15000)});
 let data={};try{data=await r.json()}catch{}
 if(!r.ok){const e=new Error('Yandex API '+r.status);e.status=r.status;throw e}return data;
}
function safeHref(s){const u=new URL(s),host=u.hostname.toLowerCase();if(u.protocol!=='https:'||!(host==='yandex.ru'||host.endsWith('.yandex.ru')||host.endsWith('.yandex.net')||host.endsWith('.yandex.com')))throw Error('Invalid Yandex transfer host');return u.href}
async function readJson(path){let meta;try{meta=await api('/resources/download?'+qs({path}))}catch(e){if(e.status===404)return null;throw e}
 const r=await fetch(safeHref(meta.href),{signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error('Disk download '+r.status);return r.json()}
async function putJson(path,obj,overwrite=false){const content=JSON.stringify(obj);if(content.length>180000)throw Error('Data too large');const up=await api('/resources/upload?'+qs({path,overwrite:String(overwrite)}));const r=await fetch(safeHref(up.href),{method:up.method||'PUT',headers:{'Content-Type':'application/json'},body:content,signal:AbortSignal.timeout(15000)});if(!r.ok){const e=new Error('Upload '+r.status);e.status=r.status;throw e}}
async function folder(path){try{await api('/resources?'+qs({path}),'PUT')}catch(e){if(e.status!==409)throw e}}
async function base(){await folder(ROOT);await folder(PROJECTS);await folder(CONVOS);await folder(MESSAGES)}
async function list(path,max=1000){let items=[],offset=0;for(let page=0;page<5;page++){
 let v;try{v=await api('/resources?'+qs({path,limit:'1000',offset:String(offset)}))}catch(e){if(e.status===404)return [];throw e}
 const batch=v._embedded?.items||[];items.push(...batch);offset+=batch.length;
 if(!batch.length||offset>=(v._embedded?.total||0))return items;
 }throw Object.assign(new Error('Folder too large'),{status:413})}
async function parallelMap(arr,limit,fn){let n=0;const results=Array(arr.length);await Promise.all(Array.from({length:Math.min(limit,arr.length)},async()=>{while(n<arr.length){let i=n++;results[i]=await fn(arr[i])}}));return results}
async function records(path){const names=(await list(path)).filter(v=>v.type==='file'&&uuid(v.name?.replace(/\.json$/,''))&&v.name.endsWith('.json'));return (await parallelMap(names,5,v=>readJson(path+'/'+v.name))).filter(Boolean)}
async function projectsAndConvos(){const [projects,convos]=await Promise.all([records(PROJECTS),records(CONVOS)]);return {projects:projects.filter(x=>!x.deletedAt),convos:convos.filter(x=>!x.deletedAt)} }
async function readResource(kind,id){if(!uuid(id))return null;const root=kind==='project'?PROJECTS:CONVOS;return readJson(root+'/'+id+'.json')}
async function getMessage(convo,id){if(!uuid(convo)||!uuid(id))return null;return readJson(MESSAGES+'/'+convo+'/'+id+'.json')}
function checkOrigin(req){const origin=req.headers.get('origin');try{return origin&&new URL(origin).origin===new URL(req.url).origin}catch{return false}}
export default async function handler(req){
 if(!process.env.YANDEX_DISK_TOKEN)return reply({error:'Хранилище не настроено'},503);
 if(!['GET','POST'].includes(req.method))return reply({error:'Method not allowed'},405);
 if(req.method==='POST'&&(!checkOrigin(req)||!req.headers.get('content-type')?.startsWith('application/json')))return reply({error:'Invalid origin'},403);
 try{
  const session=await getSession(req);if(!session)return reply({error:'Требуется вход'},401);
  let b={};if(req.method==='POST'){try{b=await req.json()}catch{return reply({error:'Invalid JSON'},400)}}
  const url=new URL(req.url),action=req.method==='GET'?url.searchParams.get('action'):b.action;
  if(action==='overview'&&req.method==='GET')return reply(await projectsAndConvos());
  if(action==='createProject'&&req.method==='POST'){
   const name=trimmed(b.name,100);if(!name)return reply({error:'Введите имя проекта'},400);
   await base();const existing=await records(PROJECTS);if(existing.some(x=>x.name?.toLocaleLowerCase('ru')===name.toLocaleLowerCase('ru')&&!x.deletedAt))return reply({error:'Проект с таким названием уже существует'},409);
   const folderName=safeFolderName(name);if(folderName.toLowerCase()==='_system')return reply({error:'Служебное имя папки запрещено'},400);
   const id=randomUUID(),folderPath='app:/'+folderName;await folder(folderPath);
   const p={id,name,folderPath,createdAt:now(),createdBy:session.user.id};
   await putJson(PROJECTS+'/'+p.id+'.json',p);return reply({project:p});
  }
  if(action==='updateProject'&&req.method==='POST'){
   const p=await readResource('project',b.id),name=trimmed(b.name,100);if(!p||p.deletedAt)return reply({error:'Проект не найден'},404);
   if(!name)return reply({error:'Введите имя проекта'},400);
   if(b.avatar!==undefined){if(!validAvatar(b.avatar))return reply({error:'Недопустимый аватар'},400);p.avatar=b.avatar}
   // Keep folderPath stable on rename until the file explorer move/rename operation is supported.
   p.name=name;p.updatedAt=now();await putJson(PROJECTS+'/'+p.id+'.json',p,true);return reply({project:p});
  }
  if(action==='createConvo'&&req.method==='POST'){
   const p=await readResource('project',b.project),name=trimmed(b.name,100);if(!p||p.deletedAt)return reply({error:'Проект не найден'},404);
   if(!name)return reply({error:'Введите имя беседы'},400);
   await folder(CONVOS);await folder(MESSAGES);
   const c={id:randomUUID(),project:p.id,name,createdAt:now()};
   await putJson(CONVOS+'/'+c.id+'.json',c);await folder(MESSAGES+'/'+c.id);return reply({convo:c});
  }
  if(action==='updateConvo'&&req.method==='POST'){
   const c=await readResource('convo',b.id),name=trimmed(b.name,100);if(!c||c.deletedAt)return reply({error:'Беседа не найдена'},404);if(!name)return reply({error:'Введите имя беседы'},400);
   if(b.avatar!==undefined){if(!validAvatar(b.avatar))return reply({error:'Недопустимый аватар'},400);c.avatar=b.avatar}
   c.name=name;c.updatedAt=now();await putJson(CONVOS+'/'+c.id+'.json',c,true);return reply({convo:c});
  }
  if(action==='messages'&&req.method==='GET'){
   const convo=url.searchParams.get('convo');if(!uuid(convo))return reply({error:'Invalid conversation'},400);
   const c=await readResource('convo',convo);if(!c||c.deletedAt)return reply({error:'Беседа не найдена'},404);
   const since=Number(url.searchParams.get('since')||0);if(!Number.isFinite(since)||since<0)return reply({error:'Invalid cursor'},400);
   const all=(await list(MESSAGES+'/'+convo)).filter(x=>x.type==='file'&&uuid(x.name?.replace(/\.json$/,''))&&x.name.endsWith('.json'));
   if(all.length>1000)return reply({error:'Лимит тестового хранилища: 1000 сообщений на беседу'},413);
   // Re-read only new/changed files on subsequent refreshes (15s overlap for provider timestamp lag).
   const changed=since>0?all.filter(x=>!x.modified||Date.parse(x.modified)>=since-15000):all;
   const rows=(await parallelMap(changed,5,x=>readJson(MESSAGES+'/'+convo+'/'+x.name))).filter(x=>x&&x.convo===convo);
   return reply({messages:rows.sort((a,b)=>a.time-b.time||a.id.localeCompare(b.id)),cursor:now(),initial:!since});
  }
  if(action==='send'&&req.method==='POST'){
   const c=await readResource('convo',b.convo);if(!c||c.deletedAt)return reply({error:'Беседа не найдена'},404);
   const text=trimmed(b.text,6000);if(!text)return reply({error:'Введите сообщение'},400);
   const id=uuid(b.requestId)?b.requestId:randomUUID();
   const m={id,convo:c.id,authorId:session.user.id,who:session.user.name,text,time:now()};
   await folder(MESSAGES+'/'+c.id);
   try{await putJson(MESSAGES+'/'+c.id+'/'+m.id+'.json',m)}catch(err){
    if(err.status!==409)throw err;
    const prior=await getMessage(c.id,id);
    if(prior?.authorId!==session.user.id||prior?.text!==text)return reply({error:'Конфликт идентификатора сообщения'},409);
    return reply({message:prior,repeated:true});
   }
   return reply({message:m});
  }
  if(['edit','delete'].includes(action)&&req.method==='POST'){
   if(!uuid(b.convo)||!uuid(b.id))return reply({error:'Invalid identifiers'},400);
   const m=await getMessage(b.convo,b.id);if(!m||m.deletedAt)return reply({error:'Сообщение не найдено'},404);
   if(m.authorId!==session.user.id)return reply({error:'Можно изменять только свои сообщения'},403);
   if(action==='edit'){const t=trimmed(b.text,6000);if(!t)return reply({error:'Сообщение не может быть пустым'},400);m.text=t;m.editedAt=now()}
   else m.deletedAt=now();
   await putJson(MESSAGES+'/'+m.convo+'/'+m.id+'.json',m,true);return reply({message:m});
  }
  return reply({error:'Unknown action'},404);
 }catch(err){console.error('ARTAE sync',String(err?.message||err));return reply({error:err?.status===413?'Слишком много объектов в папке':'Ошибка синхронизации с Яндекс Диском. Повторите попытку.'},err?.status===413?413:502)}
}
