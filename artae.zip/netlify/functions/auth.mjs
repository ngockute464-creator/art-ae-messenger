// ART-AE private beta: secret access keys, HttpOnly sessions; Yandex app folder only.
// This is intentionally separate from the (still local-only) demonstration chats.
import { randomBytes, randomUUID, createHash, timingSafeEqual } from 'node:crypto';

const API='https://cloud-api.yandex.net/v1/disk';
const ROOT='app:/_system';
const USERS=`${ROOT}/users.json`;
const SESSIONS=`${ROOT}/sessions`;
const DAYS_180=180*24*60*60*1000;
const COOKIE='__Host-artae_session';
const hash=s=>createHash('sha256').update(s).digest('hex');
const safeEqual=(a,b)=>{const x=Buffer.from(String(a||'')),y=Buffer.from(String(b||''));return x.length===y.length&&timingSafeEqual(x,y)};
const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};
const reply=(data,status=200,extra={})=>Response.json(data,{status,headers:{...headers,...extra}});
const enc=p=>new URLSearchParams({path:p}).toString();
const secret=()=>randomBytes(32).toString('base64url');
const cookie=(value,seconds)=>`${COOKIE}=${value}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${seconds}`;
const cleanName=s=>typeof s==='string'?s.trim().slice(0,80):'';
const diskToken=()=>process.env.YANDEX_DISK_TOKEN;

async function api(path,method='GET'){
  const response=await fetch(API+path,{method,headers:{Authorization:`OAuth ${diskToken()}`},signal:AbortSignal.timeout(14000)});
  const raw=await response.text();let body={};try{body=JSON.parse(raw)}catch{}
  if(!response.ok){const err=new Error(`Disk API ${response.status}`);err.status=response.status;throw err}
  return body;
}
function safeHref(href){
 const u=new URL(href),host=u.hostname.toLowerCase();
 if(u.protocol!=='https:'||!(host==='yandex.ru'||host.endsWith('.yandex.ru')||host.endsWith('.yandex.net')||host.endsWith('.yandex.com')))throw new Error('Unexpected transfer domain');
 return u.toString();
}
async function readJson(path){
 let response;
 try{response=await api(`/resources/download?${enc(path)}`)}catch(err){if(err.status===404)return null;throw err}
 const get=await fetch(safeHref(response.href),{signal:AbortSignal.timeout(14000)});
 if(!get.ok)throw new Error(`Disk download ${get.status}`);
 return JSON.parse(await get.text());
}
async function putJson(path,value,overwrite=true){
 const data=JSON.stringify(value);
 if(data.length>100000)throw new Error('Record too large');
 const upload=await api(`/resources/upload?${new URLSearchParams({path,overwrite:String(overwrite)})}`);
 const res=await fetch(safeHref(upload.href),{method:upload.method||'PUT',body:data,headers:{'Content-Type':'application/json'},signal:AbortSignal.timeout(14000)});
 if(!res.ok){const err=new Error(`Disk upload ${res.status}`);err.status=res.status;throw err}
}
async function folder(path){
 try{await api(`/resources?${enc(path)}`,'PUT')}catch(err){if(err.status!==409)throw err}
}
async function ensureFolders(){await folder(ROOT);await folder(SESSIONS)}
async function getUsers(){const result=await readJson(USERS);return result??{version:1,users:[]}}
async function saveUsers(value){await putJson(USERS,value)}
async function getSession(request){
 const token=(request.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(`${COOKIE}=`))?.slice(COOKIE.length+1);
 if(!token||!/^[A-Za-z0-9_-]{43}$/.test(token))return null;
 const sid=hash(token),item=await readJson(`${SESSIONS}/${sid}.json`);
 if(!item||item.sid!==sid||!item.userId||!Number.isFinite(item.lastSeen)||Date.now()-item.lastSeen>DAYS_180)return null;
 const users=await getUsers(),user=users.users.find(u=>u.id===item.userId&&!u.disabled);
 if(!user||item.generation!==user.generation)return null;
 return {token,sid,item,user,users};
}
function userView(u){return {id:u.id,name:u.name,role:u.role,disabled:!!u.disabled}}
async function newSession(user){
 const token=secret(),sid=hash(token),now=Date.now();
 await putJson(`${SESSIONS}/${sid}.json`,{sid,userId:user.id,generation:user.generation,lastSeen:now,createdAt:now},false);
 return token;
}
function sameOrigin(request){
 const origin=request.headers.get('origin');
 if(!origin)return false;
 try{return new URL(origin).origin===new URL(request.url).origin}catch{return false}
}
export default async function handler(request){
 if(!diskToken())return reply({error:'Server storage not configured'},503);
 const isGet=request.method==='GET';
 if(!isGet&&request.method!=='POST')return reply({error:'Method not allowed'},405);
 if(!isGet&&(!sameOrigin(request)||!(request.headers.get('content-type')||'').startsWith('application/json')))return reply({error:'Invalid origin or request'},403);
 try{
  const url=new URL(request.url);const action=isGet?url.searchParams.get('action'):null;
  let body={};if(!isGet){try{body=await request.json()}catch{return reply({error:'Invalid JSON'},400)}}
  const method=action||body.action;
  if(method==='status'&&isGet){const users=await getUsers();return reply({initialized:users.users.some(u=>u.role==='admin')})}
  if(method==='bootstrap'&&!isGet){
   const setup=process.env.ARTAE_SETUP_KEY;
   if(!setup||setup.length<20||!safeEqual(body.setupKey,setup))return reply({error:'Неверный установочный ключ'},403);
   await ensureFolders();
   const users=await getUsers();if(users.users.some(u=>u.role==='admin'))return reply({error:'Администратор уже создан'},409);
   const name=cleanName(body.name)||'Администратор',key=secret();
   const admin={id:randomUUID(),name,role:'admin',keyHash:hash(key),generation:1,disabled:false};
   users.users.push(admin);await saveUsers(users);
   return reply({ok:true,accessKey:key,user:userView(admin)});
  }
  if(method==='login'&&!isGet){
   const access=String(body.accessKey||'');
   if(!/^[A-Za-z0-9_-]{43}$/.test(access))return reply({error:'Неверный ключ доступа'},401);
   const users=await getUsers(),keyHash=hash(access);
   const user=users.users.find(u=>!u.disabled&&safeEqual(u.keyHash,keyHash));
   if(!user)return reply({error:'Неверный ключ доступа'},401);
   await ensureFolders();const token=await newSession(user);
   return reply({ok:true,user:userView(user)},200,{'Set-Cookie':cookie(token,180*24*60*60)});
  }
  const session=await getSession(request);
  if(!session){return reply({error:'Требуется вход'},401,{'Set-Cookie':cookie('',0)})}
  if(method==='me'&&isGet){
   const extra={};if(Date.now()-session.item.lastSeen>24*60*60*1000){
    session.item.lastSeen=Date.now();await putJson(`${SESSIONS}/${session.sid}.json`,session.item);
    extra['Set-Cookie']=cookie(session.token,180*24*60*60);
   }
   return reply({ok:true,user:userView(session.user)},200,extra);
  }
  if(method==='logout'&&!isGet){
   // Invalidate server-side. Failure must not result in silent false success.
   await api(`/resources?${new URLSearchParams({path:`${SESSIONS}/${session.sid}.json`,permanently:'true'})}`,'DELETE');
   return reply({ok:true},200,{'Set-Cookie':cookie('',0)});
  }
  if(session.user.role!=='admin')return reply({error:'Доступ только администратору'},403);
  if(method==='users'&&isGet)return reply({users:session.users.users.map(userView)});
  if(method==='createUser'&&!isGet){
   if(session.users.users.length>=5)return reply({error:'Предел 5 пользователей для тестовой версии'},409);
   const name=cleanName(body.name);if(name.length<2)return reply({error:'Введите имя пользователя'},400);
   const key=secret(),user={id:randomUUID(),name,role:'member',keyHash:hash(key),generation:1,disabled:false};
   session.users.users.push(user);await saveUsers(session.users);
   return reply({ok:true,user:userView(user),accessKey:key});
  }
  if(method==='reissueKey'&&!isGet){
   const user=session.users.users.find(u=>u.id===body.userId&&u.role!=='admin');if(!user)return reply({error:'Пользователь не найден'},404);
   const key=secret();user.keyHash=hash(key);user.generation++;await saveUsers(session.users);
   return reply({ok:true,user:userView(user),accessKey:key});
  }
  if(method==='disableUser'&&!isGet){
   const user=session.users.users.find(u=>u.id===body.userId&&u.role!=='admin');if(!user)return reply({error:'Пользователь не найден'},404);
   user.disabled=true;user.generation++;await saveUsers(session.users);
   return reply({ok:true});
  }
  return reply({error:'Unknown action'},404);
 }catch(err){console.error('ARTAE auth:',String(err?.message||err));return reply({error:'Временная ошибка сервера. Повторите попытку.'},502)}
}

export {getSession};
